//
//  SecondPageController.swift
//  <20180424>_<Abete>_<YOOX>
//
//  Created by Dario Abete on 21/04/18.
//  Copyright © 2018 Dario Abete. All rights reserved.
//

import UIKit

class SecondPageController: UIViewController {
	
	var data : Json!
	@IBOutlet weak var brandName: UILabel!
	@IBOutlet weak var categoryName: UILabel!
	@IBOutlet weak var colourList: UILabel!
	@IBOutlet weak var sizesList: UILabel!
	@IBOutlet weak var productInfo: UITextView!
	@IBOutlet weak var productImage: UIImageView!
	@IBOutlet weak var price: UILabel!
	
	
	override func viewDidLoad() {
		super.viewDidLoad()
		
		self.navigationController?.navigationBar.topItem?.title = "Back"
		// Do any additional setup after loading the view.
		
		//Implementing URL Session
		let urlSecond = "http://5aaf9b98bcad130014eeaf0b.mockapi.io/ynap/v1/item"
		guard let second = URL(string:urlSecond) else {return}
		
		URLSession.shared.dataTask(with: second) { (dat,respons,err) in
			
			if err != nil
			{
				print(err!.localizedDescription)
			}
			
			guard let dat = dat else {return}
			
			do
			{
				//assinging JSON values to let callData
				let callData = try JSONDecoder().decode(Json.self, from: dat)
				
				DispatchQueue.main.async
					{
						//now var data owns the values from the JSON
						self.data = callData
						
						self.brandName.text = "Brand: \(self.data.brand.brandName)"
						
						self.categoryName.text = "Categoria: \(self.data.category.categoryName)"
						
						//there is more than one element, they will be displayed on the same line
						self.colourList.text = "Colori disponibili: " + (self.data.colors.map {
							$0.colorName
						}).joined(separator: ", ")
						
						//there is more than one element, they will be displayed on the same line
						self.sizesList.text = "Taglie disponibili: " + (self.data.sizes.map {
							$0.sizeName
						}).joined(separator: ", ")
						
						//there is more than one element, they will be displayed on the same line(inside the textField)
						self.productInfo.text = self.data.itemDesc.productInfo.joined(separator: "\n\n")
						
						//return the first two letters of cod10(for images)
						let oneTwo = self.data.codice.prefix(2)
						
						let imageString = "https://cdn.yoox.biz/"+"\(String(describing: oneTwo))"+"/"+"\(String(describing: self.data.codice))"+"_11_f.jpg"
						
						let imageUrl = URL(string: imageString)
						
						DispatchQueue.global().async{
							
							//getting the image
							let pic = try? Data(contentsOf: imageUrl!)
							
							//assigning the image to the view
							DispatchQueue.main.async{
								self.productImage.image = UIImage(data: pic!)
							}
						}
						
						//which price will be shown?
						if self.data.formPrice.discPrice < self.data.formPrice.fullPrice
						{
							self.price.text = self.data.formPrice.discPrice
						}
						else
						{
							self.price.text = self.data.formPrice.fullPrice
						}
						
				}
				
			}
				
			catch let jsonErr
			{
				print(jsonErr)
			}
			
			}.resume()
		
	}
	
	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}
	
	
	
	/*
	// MARK: - Navigation
	
	// In a storyboard-based application, you will often want to do a little preparation before navigation
	override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
	// Get the new view controller using segue.destinationViewController.
	// Pass the selected object to the new view controller.
	}
	*/
	
}
