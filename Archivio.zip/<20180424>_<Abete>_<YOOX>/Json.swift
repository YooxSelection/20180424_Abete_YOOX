//
//  Item2.swift
//  <20180424>_<Abete>_<YOOX>
//
//  Created by Dario Abete on 21/04/18.
//  Copyright © 2018 Dario Abete. All rights reserved.
//

import Foundation

//These are the data that are going to be taken from the JSON
struct Json: Codable{
	private enum CodingKeys: String,CodingKey{
		
		case itemDesc = "ItemDescriptions"
		case codice = "Cod10"
		case brand = "Brand"
		case category = "Category"
		case formPrice = "FormattedPrice"
		case colors = "Colors"
		case sizes = "Sizes"
	}
	
	let itemDesc : ItemDescription
	let codice: String
	let brand: Brand
	let category : Category
	let formPrice : FormattedPrice
	let colors: [Colors]
	let sizes: [Sizes]
}

//"ItemDescriptions" contains two more elements, but actually only the procuctInfo will be used
struct ItemDescription: Codable {
	private enum CodingKeys: String,CodingKey{
		case sizeInfo = "SizeInfo"
		case productInfo = "ProductInfo"
	}
	
	let sizeInfo : String
	let productInfo:[String]
}

//Brand name will be getting
struct Brand: Codable{
	private enum CodingKeys: String,CodingKey{
		case brandName = "Name"
	}
	
	var brandName: String
}

//Category name will be getting
struct Category:Codable{
	private enum CodingKeys: String,CodingKey{
		case categoryName = "Name"
	}
	
	var categoryName :String
}

//Elements from "FormattedPrice" will be getting
struct FormattedPrice:Codable{
	private enum CodingKeys: String,CodingKey{
		case fullPrice = "FullPrice"
		case discPrice = "DiscountedPrice"
		case retail = "RetailPrice"
	}
	
	var fullPrice: String
	var discPrice: String
	var retail: String
	
}

//Elements from Colors array will be getting
struct Colors: Codable{
	private enum CodingKeys: String,CodingKey{
		case colorId = "ColorId"
		case colorCode = "ColorCode"
		case code10 = "Code10"
		case colorName = "Name"
		case rgb = "Rgb"
	}
	
	var colorId:Int
	var colorCode:String
	var code10:String
	var colorName:String
	var rgb:String
	
}

//Elements from Sizes array will be getting
struct Sizes:Codable{
	private enum CodingKeys: String,CodingKey{
		case sizeId = "Id"
		case countryCode = "IsoTwoLetterCountryCode"
		case defaultSize = "DefaultSizeLabel"
		case sizeName = "Name"
		case altSize = "AlternativeSizeLabel"
	}
	
	var sizeId:Int
	var countryCode:String
	var defaultSize:String
	var sizeName:String
	var altSize:String
	
}
