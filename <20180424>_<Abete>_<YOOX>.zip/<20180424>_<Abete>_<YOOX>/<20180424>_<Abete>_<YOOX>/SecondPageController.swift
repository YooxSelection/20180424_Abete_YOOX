//
//  SecondPageController.swift
//  <20180424>_<Abete>_<YOOX>
//
//  Created by Dario Abete on 21/04/18.
//  Copyright © 2018 Dario Abete. All rights reserved.
//

import UIKit

class SecondPageController: UIViewController {
	
	var data : Json!
	@IBOutlet weak var brandName: UILabel!
	@IBOutlet weak var categoryName: UILabel!
	@IBOutlet weak var colourList: UILabel!
	@IBOutlet weak var sizesList: UILabel!
	@IBOutlet weak var productInfo: UITextView!
	@IBOutlet weak var productImage: UIImageView!
	@IBOutlet weak var price: UILabel!
	
	
	override func viewDidLoad() {
        super.viewDidLoad()
		
		self.navigationController?.navigationBar.topItem?.title = "Back"
        // Do any additional setup after loading the view.
		
		let urlSecond = "http://5aaf9b98bcad130014eeaf0b.mockapi.io/ynap/v1/item"
		guard let second = URL(string:urlSecond) else {return}
		
		URLSession.shared.dataTask(with: second) { (dat,respons,err) in
			
			if err != nil
			{
				print(err!.localizedDescription)
			}
			
			guard let dat = dat else {return}
			
			do
			{
				let callData = try JSONDecoder().decode(Json.self, from: dat)
				
				DispatchQueue.main.async
				{
					self.data = callData
					
					self.brandName.text = "Brand: \(self.data.brand.brandName)"
					
					self.categoryName.text = "Categoria: \(self.data.category.categoryName)"
					
					self.colourList.text = "Colori disponibili: " + (self.data.colors.map {
						$0.colorName
					}).joined(separator: ", ")
					
					self.sizesList.text = "Taglie disponibili: " + (self.data.sizes.map {
						$0.sizeName
					}).joined(separator: ", ")
					
					self.productInfo.text = self.data.itemDesc.productInfo.joined(separator: "\n\n")
					
					let oneTwo = self.data.codice.prefix(2)
					let imageString = "https://cdn.yoox.biz/"+"\(String(describing: oneTwo))"+"/"+"\(String(describing: self.data.codice))"+"_11_f.jpg"
					
					let imageUrl = URL(string: imageString)
					
					DispatchQueue.global().async{
						let pic = try? Data(contentsOf: imageUrl!)
						DispatchQueue.main.async{
							self.productImage.image = UIImage(data: pic!)
						}
					}
					
					if self.data.formPrice.discPrice < self.data.formPrice.fullPrice
					{
						self.price.text = self.data.formPrice.discPrice
					}
					else
					{
						self.price.text = self.data.formPrice.fullPrice
					}
					
			}
						
		}
		
		catch let jsonErr
		{
			print(jsonErr)
		}

	}.resume()
		
		
		
		
}

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
	
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
