//
//  Item2.swift
//  <20180424>_<Abete>_<YOOX>
//
//  Created by Dario Abete on 21/04/18.
//  Copyright © 2018 Dario Abete. All rights reserved.
//

import Foundation

struct Json: Codable{
	private enum CodingKeys: String,CodingKey{
		
		case itemDesc = "ItemDescriptions"
		case codice = "Cod10"
		case brand = "Brand"
		case category = "Category"
		case formPrice = "FormattedPrice"
		case colors = "Colors"
		case sizes = "Sizes"
	}
	
	let itemDesc : ItemDescription
	let codice: String
	let brand: Brand
	let category : Category
	let formPrice : FormattedPrice
	let colors: [Colors]
	let sizes: [Sizes]
}

struct ItemDescription: Codable {
	private enum CodingKeys: String,CodingKey{
	case sizeInfo = "SizeInfo"
	case productInfo = "ProductInfo"
	}
	
	let sizeInfo : String
	let productInfo:[String]
}


struct Brand: Codable{
	private enum CodingKeys: String,CodingKey{
		case brandName = "Name"
	}
	
	var brandName: String
}


struct Category:Codable{
	private enum CodingKeys: String,CodingKey{
		case categoryName = "Name"
	}
	
	var categoryName :String
}


struct FormattedPrice:Codable{
	private enum CodingKeys: String,CodingKey{
		case fullPrice = "FullPrice"
		case discPrice = "DiscountedPrice"
		case retail = "RetailPrice"
	}
	
	var fullPrice: String
	var discPrice: String
	var retail: String
	
}

struct Colors: Codable{
	private enum CodingKeys: String,CodingKey{
		case colorId = "ColorId"
		case colorCode = "ColorCode"
		case code10 = "Code10"
		case colorName = "Name"
		case rgb = "Rgb"
	}
	
	var colorId:Int
	var colorCode:String
	var code10:String
	var colorName:String
	var rgb:String
	
}

struct Sizes:Codable{
	private enum CodingKeys: String,CodingKey{
		case sizeId = "Id"
		case countryCode = "IsoTwoLetterCountryCode"
		case defaultSize = "DefaultSizeLabel"
		case sizeName = "Name"
		case altSize = "AlternativeSizeLabel"
	}
	
	var sizeId:Int
	var countryCode:String
	var defaultSize:String
	var sizeName:String
	var altSize:String
	
}
