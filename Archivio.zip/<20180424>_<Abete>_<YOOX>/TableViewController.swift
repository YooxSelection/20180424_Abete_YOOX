//
//  TableViewController.swift
//  <20180424>_<Abete>_<YOOX>
//
//  Created by Dario Abete on 20/04/18.
//  Copyright © 2018 Dario Abete. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController, UISearchResultsUpdating,UISearchBarDelegate {
	
	//let used as reference for TableView cell
	fileprivate let cellId = "cellId"
	
	//items will contain the data decoded from the JSON, filteredItems will be used to do the filtering
	var items :[Item]?
	var filteredItems = [Item]()
	
	//search bar
	let controller = UISearchController(searchResultsController: nil)
	
	// this variables will be used to keep track of the "infinite" scrolling
	var itemsPerScroll:Int?
	var offset = 0
	var isViewScrolledDown = false
	
	
	//to implement the searching mode
	func updateSearchResults(for searchController: UISearchController)
	{
		print("Sto per fare una ricerca!")
		
		let bar = searchController.searchBar
		let scope = bar.scopeButtonTitles![bar.selectedScopeButtonIndex]
		filterContentForSearch(searchController.searchBar.text!,scope: scope)
	}
	
	override func viewDidLoad() {
		super.viewDidLoad()
		
		//implementing the tableView
		tableView?.register(ArticleViewCell.self, forCellReuseIdentifier: cellId)
		tableView.rowHeight = UITableViewAutomaticDimension
		tableView.estimatedRowHeight = 170
		tableView.dataSource = self
		tableView.delegate = self
		
		//removes the background tableView to show the result of the filtering
		controller.dimsBackgroundDuringPresentation = false
		
		//implementing the searchResultUpdater, who is going to be responsible for the search events
		controller.searchResultsUpdater = self
		
		//search bar will adapt to app dimensions
		controller.searchBar.sizeToFit()
		
		//view will not shadow when search bar is activer
		controller.obscuresBackgroundDuringPresentation = false
		
		//a simple string inside the search bar
		controller.searchBar.placeholder = "Search item by brand or category..."
		
		//naming the buttons in the search bar
		controller.searchBar.scopeButtonTitles = ["All","Brand","Category"]
		
		//search bar implementation
		controller.searchBar.delegate = self
		
		//search bar will be attached to the top bound of the tableView
		self.tableView.tableHeaderView = controller.searchBar
		
		
		
		//Implementing URL Session
		let urlString = "http://5aaf9b98bcad130014eeaf0b.mockapi.io/ynap/v1/searchresult"
		guard let url = URL(string:urlString) else {return}
		
		URLSession.shared.dataTask(with: url) { (data,response,error) in
			if error != nil
			{
				print(error!.localizedDescription)
			}
			
			guard let data = data else {return}
			
			do
			{
				let itemData = try JSONDecoder().decode(Dict.self, from: data)
				
				DispatchQueue.main.async
					{
						self.items = itemData.item
						self.tableView.reloadData()
				}
			}
				
			catch let jsonError
			{
				print(jsonError)
			}
			
			}.resume()
		
		
		// Uncomment the following line to preserve selection between presentations
		// self.clearsSelectionOnViewWillAppear = false
		
		// Uncomment the following line to display an Edit button in the navigation bar for this view controller.
		// self.navigationItem.rightBarButtonItem = self.editButtonItem
	}
	
	func searchBarIsEmpty() -> Bool {
		// Returns true if the text is empty or nil
		return controller.searchBar.text?.isEmpty ?? true
	}
	
	
	func filterContentForSearch(_ searchText: String, scope: String) {
		
		//adding objects to the filteredItems array based on the search
		filteredItems = items!.filter({( elem : Item) -> Bool in
			
			let isCategoryMatching = (scope == "All") || (scope == "Brand") || (scope == "Category")
			
			if searchBarIsEmpty(){
				return isCategoryMatching
			}
			else
			{
				//if search filter is by brand and category, the query will return both the parameters
				if scope == "All"
				{
					return elem.brand.lowercased().contains(searchText.lowercased()) || elem.microCat.lowercased().contains(searchText.lowercased())
				}
				//if search filter is only by brand, the qyery will return just the parameters linked to it
				else if scope == "Brand"
				{
					return elem.brand.lowercased().contains(searchText.lowercased())
				}
				//if search filter is only by category, the qyery will return just the parameters linked to it
				else if scope == "Category"
				{
					return elem.microCat.lowercased().contains(searchText.lowercased())
				}
				
			}
			
			return isCategoryMatching
		})
		
		self.tableView.reloadData()
	}
	
	//this function will be activated everytime a query is done
	func isFiltering() -> Bool {
		let barIsFiltering = controller.searchBar.selectedScopeButtonIndex != 0
		return controller.isActive && (!searchBarIsEmpty() || barIsFiltering)
	}
	
	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}
	
	// MARK: - Table view data source
	override func numberOfSections(in tableView: UITableView) -> Int {
		// #warning Incomplete implementation, return the number of sections
		
		//default number of sections
		var sections: Int = 1
		
		//if the user is making a query, the filteredItems array will be added of new elements. If the query doesn't match an item, a label will be shown
		if isFiltering()
		{
			if self.filteredItems.count != 0
			{
				tableView.separatorStyle = .singleLine
				tableView.backgroundView = nil
			}
			else
			{
				let label = UILabel(frame: CGRect(x:0, y:0, width: self.tableView.bounds.size.width, height: tableView.bounds.size.height))
				label.text = "No items found"
				label.textColor = UIColor.black
				label.textAlignment = .center
				self.tableView.backgroundView = label
				self.tableView.backgroundColor = UIColor.white
				self.tableView.separatorStyle = .none
				sections = 0
			}
		}
		return sections
	}
	
	override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		// #warning Incomplete implementation, return the number of rows
		
		//if the search bar is active, if there is no next written, nothing happens. When something is written, the tableView will show a number of lines equal to the number of elements of the filteredItems array. By default, the tableView is completed with the items from the JSON.
		if isFiltering()
		{
			if controller.searchBar.text == nil
			{
				return 1
			}
			
			return filteredItems.count
		}
		
		return items?.count ?? 0
	}
	
	override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
		
		let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as! ArticleViewCell
		
		// Configure the cell...
		
		let name = items?[indexPath.row].brand
		let cat = items?[indexPath.row].microCat
		var price:String
		{
			get{
				
				if (items?[indexPath.row].discPrice)! < (items?[indexPath.row].fullPrice)!
				{
					return (items?[indexPath.row].discPrice)!
				}
				else
				{
					return (items?[indexPath.row].fullPrice)!
				}
				
			}
			
		}
		
		//if the search bar is active, when something is written and the query matches a result, the result is showed. Correct price and image are showed, too.
		if isFiltering()
		{
			let filteredName = filteredItems[indexPath.row].brand
			cell.elemTitle.text = filteredName
			
			let filteredCategory = filteredItems[indexPath.row].microCat
			cell.category.text = filteredCategory
			
			var filteredPrice : String{
				get{
					
					if (filteredItems[indexPath.row].discPrice) < (filteredItems[indexPath.row].fullPrice)
					{
						return (filteredItems[indexPath.row].discPrice)
					}
					else
					{
						return (filteredItems[indexPath.row].fullPrice)
					}
					
				}
				
			}
			
			cell.price.text = filteredPrice
		}
		//if search bar is not active, items are just shown.
		else
		{
			cell.elemTitle.text = name!
			cell.category.text = cat!
			cell.price.text = price
		}
		
		
		
		//return the first two letters of cod10(used for images)
		var oneTwo :String
		{
			get
			{
				//if search bar is active, only the elements of filteredItem array are processed
				if isFiltering()
				{
					return (String(filteredItems[indexPath.row].cod.prefix(2)))
				}
				//if search bar is not active, all elements are processed
				else
				{
					return (String((items?[indexPath.row].cod.prefix(2))!))
				}
				
			}
		}
		
		//returns cod10(used for images)
		var cod10 :String
		{
			get
			{
				//same implementation as before
				if isFiltering()
				{
					return (String(filteredItems[indexPath.row].cod))
				}
				else
				{
					return (String(items![indexPath.row].cod))
				}
				
			}
		}
		
		//this var is not dependent on the search!
		let imageURLString = "https://cdn.yoox.biz/"+"\(String(describing: oneTwo))"+"/"+"\(String(describing: cod10))"+"_11_f.jpg"
		
		let imageURL = URL(string: imageURLString)
		
		//Implementing URL session to add image to tableView
		let session = URLSession(configuration: .default)
		
		let getImageFromUrl = session.dataTask(with: imageURL!) { (data, response, error) in
			
			//if there is any error
			if let e = error {
				//displaying the message
				print("Error Occurred: \(e)")
				
			} else {
				//in case of now error, checking wheather the response is nil or not
				if (response as? HTTPURLResponse) != nil {
					
					//checking if the response contains an image
					if let imageData = data {
						
						//getting the image
						let image = UIImage(data: imageData)
						
						DispatchQueue.main.async
							{
								//image added to tableView
								cell.img.image = image
						}
						
					}
					else
					{
						print("Image file is currupted")
					}
				}
				else
				{
					print("No response from server")
				}
			}
		}
		
		getImageFromUrl.resume()
		
		//when the user scrolls down and reaches the last item, new items are added to the tableView from different JSON. The implementation of loadNewElements func is at the bottom of this page.
		if indexPath.row == (self.items?.count)! - 1
		{
			self.loadNewElements(urlString2: "http://5aaf9b98bcad130014eeaf0b.mockapi.io/ynap/v1/searchresult2")
			self.loadNewElements(urlString2: "http://5aaf9b98bcad130014eeaf0b.mockapi.io/ynap/v1/searchresult3")
		}
		
		return cell
	}
	
	override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
		
		if tableView.cellForRow(at: indexPath) != nil
		{
			
			if indexPath.row <= (items?.count)! {
				
				performSegue(withIdentifier: "2ndpageSegue", sender: nil)
			}
		}
		
	}
	
	
	
	
	
	/*
	// Override to support conditional editing of the table view.
	override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
	// Return false if you do not want the specified item to be editable.
	return true
	}
	*/
	
	/*
	// Override to support editing the table view.
	override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
	if editingStyle == .delete {
	// Delete the row from the data source
	tableView.deleteRows(at: [indexPath], with: .fade)
	} else if editingStyle == .insert {
	// Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
	}
	}
	*/
	
	/*
	// Override to support rearranging the table view.
	override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
	
	}
	*/
	
	/*
	// Override to support conditional rearranging of the table view.
	override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
	// Return false if you do not want the item to be re-orderable.
	return true
	}
	*/
	
	
	// MARK: - Navigation
	
	// In a storyboard-based application, you will often want to do a little preparation before navigation
	override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
		//if the user taps on any cell of the tableView, the second page will be shown
		if segue.identifier == "2ndpageSegue"
		{
			_ = segue.destination as! SecondPageController
		}
		// Get the new view controller using segue.destinationViewController.
		// Pass the selected object to the new view controller.
	}
	
	//func needed to implement query by more than one parameter
	func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
		filterContentForSearch(searchBar.text!, scope: searchBar.scopeButtonTitles![selectedScope])
	}
	
	func loadNewElements(urlString2:String)
	{
		//checks if the user has scrolled down to the bottom of the page
		guard !self.isViewScrolledDown else {return}
		
		DispatchQueue.global(qos: .background).async {
			
			//this var will be used to keep track of the user scrolling action
			self.itemsPerScroll = 0
			print(self.itemsPerScroll!)
			
			//Implementing URL Session
			guard let url2 = URL(string:urlString2) else {return}
			
			URLSession.shared.dataTask(with: url2) { (data2,response2,error2) in
				if error2 != nil
				{
					print(error2!.localizedDescription)
				}
				
				guard let data2 = data2 else {return}
				
				do
				{
					let itemData2 = try JSONDecoder().decode(Dict.self, from: data2)
					
					DispatchQueue.main.async {
						//assign elements from decoded JSON(related to the input String) to newItems
						let newItems = itemData2.item
						print("new items:\(newItems.count)")
						
						//adding content of newItems to items array
						self.items?.append(contentsOf: newItems)
						
						//now the user can scroll down up to the number of cells the tableView has
						self.itemsPerScroll = self.items!.count
						print("Total items:\(self.items!.count)")
						
						self.tableView.reloadData()
						
						//when there are no more elements to add, the user will not be able to scroll down the tableView 
						if newItems.count < self.itemsPerScroll!
						{
							self.isViewScrolledDown = true
							print("View scrolled down. Total number of elements: \(String(describing: self.items!.count))")
							
						}
						
						//to update the number of items inside the tableView, as soon as they are added
						self.offset += self.itemsPerScroll!
					}
				}
					
				catch let jsonError
				{
					print(jsonError)
				}
				
				}.resume()
			
		}
		
	}
}


	



