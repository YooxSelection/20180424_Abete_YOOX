//
//  Cell.swift
//  <20180424>_<Abete>_<YOOX>
//
//  Created by Dario Abete on 20/04/18.
//  Copyright © 2018 Dario Abete. All rights reserved.
//

import Foundation
import UIKit

class ArticleViewCell : UITableViewCell{
	
	
	let elemTitle = UILabel()
	let category = UILabel()
	let price = UILabel()
	let img = UIImageView()
	
	override init(style: UITableViewCellStyle, reuseIdentifier:String?)
	{
		super.init(style:style,reuseIdentifier: reuseIdentifier)
		
		elemTitle.translatesAutoresizingMaskIntoConstraints = false
		category.translatesAutoresizingMaskIntoConstraints = false
		price.translatesAutoresizingMaskIntoConstraints = false
		img.translatesAutoresizingMaskIntoConstraints = false
		
		contentView.addSubview(elemTitle)
		contentView.addSubview(category)
		contentView.addSubview(price)
		contentView.addSubview(img)
		
		let viewDictionary = [
		"name" : elemTitle,
		"category" : category,
		"price" : price,
		"image" : img,
		] as [String : Any]
		
		contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[price]-[image(30)]|", options: [], metrics: nil, views: viewDictionary))
		contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[name]-[category]|", options: [], metrics: nil, views: viewDictionary))
		contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[name]-[price]|", options: [], metrics: nil, views: viewDictionary))
		contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[category]-[image(30)]|", options: [], metrics: nil, views: viewDictionary))
	}
	
	required init?(coder aDecoder: NSCoder) {
		fatalError("Not been implemented")
	}
	
	override func awakeFromNib() {
		super.awakeFromNib()
		contentView.addSubview(elemTitle)
	}
	
	
	
}
