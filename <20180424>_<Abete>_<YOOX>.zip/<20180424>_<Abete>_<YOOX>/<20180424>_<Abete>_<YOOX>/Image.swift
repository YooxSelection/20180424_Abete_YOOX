//
//  Image.swift
//  <20180424>_<Abete>_<YOOX>
//
//  Created by Dario Abete on 21/04/18.
//  Copyright © 2018 Dario Abete. All rights reserved.
//

import Foundation

class Image: UIImageView{
	
	
	
	
	
}
