//
//  Item.swift
//  <20180424>_<Abete>_<YOOX>
//
//  Created by Dario Abete on 20/04/18.
//  Copyright © 2018 Dario Abete. All rights reserved.
//

import Foundation

//JSON file contains an "Items" array to decode
struct Dict: Codable{
	
	private enum CodingKeys: String, CodingKey
	{
		case item = "Items"
	}
	
	let item: [Item]
}

//From "Items" , brand name, category name, price (discounted or full) and a code to get a pic will be getting
struct Item : Codable{
	
	private enum CodingKeys: String,CodingKey{
		case brand = "Brand"
		case cod = "Cod10"
		case microCat = "MicroCategory"
		case discPrice = "FormattedDiscountedPrice"
		case fullPrice = "FormattedFullPrice"
	}
	
	var brand: String
	var cod: String
	var microCat: String
	var discPrice: String
	var fullPrice:String
}
